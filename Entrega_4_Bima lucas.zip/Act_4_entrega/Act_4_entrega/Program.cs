using Act_4_entrega.Interfaces;
using Act_4_entrega.Repositories;
using Act_4_entrega.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Agregar DbContext (ajust� la key "EnviosDB" en appsettings.json)
builder.Services.AddDbContext<EnviosDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("EnviosDB")));

// Registrar repository
builder.Services.AddScoped<IEnvioRepository, EnvioRepository>();

// Controllers (opcional: evitar ciclos de referencia en JSON)
builder.Services.AddControllers()
    .AddJsonOptions(o =>
        o.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
