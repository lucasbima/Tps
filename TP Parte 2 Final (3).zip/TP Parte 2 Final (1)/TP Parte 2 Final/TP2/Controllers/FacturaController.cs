﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TP1_BiMA_lUCAS_421552.Domain;
using TP1_BiMA_lUCAS_421552.Services;


namespace TP2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : ControllerBase
    {
        private FacturaService _service;

        public FacturaController()
        {
            _service = new FacturaService();
        }

        [HttpGet] //Ver todos los datos
        public IActionResult Get()
        {
            try
            {
                var facturas = _service.ObtenerFacturas();
                return Ok(facturas);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error. Ha ocurrido un error interno al obtener las facturas");
            }
        }

        [HttpGet("{id}")] //Ver datos por id
        public IActionResult Get(int id)
        {
            try
            {
                var factura = _service.ObtenerFacturaPorId(id);

                if (factura == null)
                {
                    return NotFound($"Factura con el ID {id} no encontrada");
                }
                return Ok(factura);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error. Ha ocurrido un error interno al obtener la factura");
            }
        }

        [HttpPost]
        public IActionResult Post(Factura oFactura)
        {
            try
            {
                if (oFactura == null)
                    return BadRequest("Datos de la factura inválidos");

                bool result = _service.InsertarFactura(oFactura);

                if (result)
                    return Ok("Factura guardada con éxito");
                else
                    return BadRequest("No se pudo guardar la factura");
            }
            catch (Exception)
            {
                return StatusCode(500, "Error interno al guardar la factura");
            }
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Factura oFactura)
        {
            try
            {
                if (oFactura == null)
                    return BadRequest("Datos de factura inválidos");

                oFactura.NroFactura = id; // se toma el ID de la URL

                bool result = _service.ActualizarFactura(oFactura);

                if (result)
                    return Ok("Factura actualizada con éxito");
                else
                    return NotFound("No se pudo actualizar la factura con el ID solicitado");
            }
            catch (Exception)
            {
                return StatusCode(500, "Error interno al actualizar la factura");
            }
        }


        [HttpDelete("{id}")]

        public IActionResult Delete(int id)
        {
            try
            {
                bool result = _service.EliminarFactura(id);
                if (result)
                {
                    return Ok("Facturan eliminada con exito");
                }
                else
                {
                    return NotFound("No se pudo eliminar la factura");
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Error. Ha ocurrido un error interno al guardar la factura");
            }
        }
    }
}
