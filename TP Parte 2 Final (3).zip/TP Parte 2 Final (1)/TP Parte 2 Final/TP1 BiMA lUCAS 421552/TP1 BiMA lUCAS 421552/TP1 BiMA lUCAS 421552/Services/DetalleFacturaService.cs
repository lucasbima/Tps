﻿using System.Collections.Generic;
using TP1_BiMA_lUCAS_421552.Data.Implementations;
using TP1_BiMA_lUCAS_421552.Data.Interfaces;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Services
{
    public class DetalleFacturaService
    {
        private readonly IDetalleRepository _detalleRepository;

        public DetalleFacturaService()
        {
            _detalleRepository = new DetalleRepository();
        }

        public List<DetalleFactura> ObtenerDetallesPorFactura(int nroFactura)
        {
            return _detalleRepository.GetByFactura(nroFactura);
        }

        public bool GuardarDetalle(DetalleFactura detalle)
        {
            return _detalleRepository.Save(detalle);
        }

        public bool EliminarDetalle(int id)
        {
            return _detalleRepository.Delete(id);
        }
    }
}
