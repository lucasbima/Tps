﻿using System.Collections.Generic;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Data.Interfaces
{
    public interface IDetalleRepository
    {
        List<DetalleFactura> GetByFactura(int nroFactura);
        DetalleFactura? GetById(int id);
        bool Save(DetalleFactura detalleFactura);
        bool Delete(int id);
    }
}
