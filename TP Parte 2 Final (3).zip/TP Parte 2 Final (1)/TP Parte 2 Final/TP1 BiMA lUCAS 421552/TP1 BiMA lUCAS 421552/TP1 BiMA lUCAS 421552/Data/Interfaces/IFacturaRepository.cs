﻿using System.Collections.Generic;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Data.Interfaces
{
    public interface IFacturaRepository
    {
        List<Factura> GetAll();
        Factura? GetById(int id);
        bool Insert(Factura factura);
        bool Update(Factura factura);
        bool Delete(int id);
    }
}
