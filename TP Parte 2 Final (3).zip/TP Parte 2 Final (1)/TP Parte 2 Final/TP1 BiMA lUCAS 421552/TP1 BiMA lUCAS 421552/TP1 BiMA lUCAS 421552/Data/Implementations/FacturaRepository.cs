﻿using System;
using System.Collections.Generic;
using System.Data;
using TP1_BiMA_lUCAS_421552.Data.Helpers;
using TP1_BiMA_lUCAS_421552.Data.Interfaces;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Data.Implementations
{
    public class FacturaRepository : IFacturaRepository
    {
        private readonly DataHelper _dataHelper;

        public FacturaRepository()
        {
            _dataHelper = DataHelper.GetInstance();
        }

        public List<Factura> GetAll()
        {
            var facturas = new List<Factura>();
            DataTable dt = _dataHelper.ExecuteSPQuery("sp_obtener_facturas");

            foreach (DataRow row in dt.Rows)
            {
                facturas.Add(new Factura
                {
                    NroFactura = Convert.ToInt32(row["nroFactura"]),
                    Fecha = Convert.ToDateTime(row["fecha"]),
                    IdFormaPago = Convert.ToInt32(row["idFormaPago"]),
                    Cliente = row["cliente"].ToString()
                    // FormaPagoNombre solo si tu SP lo devuelve
                });
            }
            return facturas;
        }

        public Factura? GetById(int id)
        {
            var parametros = new List<SpParameter>
            {
                new SpParameter("@idFactura", id)
            };

            DataTable dt = _dataHelper.ExecuteSPQuery("sp_obtener_factura_por_id", parametros);

            if (dt.Rows.Count == 0) return null;

            DataRow row = dt.Rows[0];
            return new Factura
            {
                NroFactura = Convert.ToInt32(row["nroFactura"]),
                Fecha = Convert.ToDateTime(row["fecha"]),
                IdFormaPago = Convert.ToInt32(row["idFormaPago"]),
                Cliente = row["cliente"].ToString()
            };
        }

        public bool Insert(Factura factura)
        {
            var parametros = new List<SpParameter>
    {
        new SpParameter("@fecha", factura.Fecha),
        new SpParameter("@idFormaPago", factura.IdFormaPago),
        new SpParameter("@cliente", factura.Cliente)
    };

            int idGenerado = _dataHelper.ExecuteSPWithOutput("sp_insertar_factura", "@idFactura", parametros);
            factura.NroFactura = idGenerado;
            return idGenerado > 0;
        }

        public bool Update(Factura factura)
        {
            var parametros = new List<SpParameter>
    {
        new SpParameter("@idFactura", factura.NroFactura),
        new SpParameter("@fecha", factura.Fecha),
        new SpParameter("@idFormaPago", factura.IdFormaPago),
        new SpParameter("@cliente", factura.Cliente)
    };

            int filasAfectadas = _dataHelper.ExecuteSPDML("sp_actualizar_factura", parametros);
            return filasAfectadas > 0;
        }


        public bool Delete(int id)
        {
            var parametros = new List<SpParameter>
            {
                new SpParameter("@idFactura", id)
            };

            int filas = _dataHelper.ExecuteSPDML("sp_eliminar_factura", parametros);
            return filas > 0;
        }
    }
}
