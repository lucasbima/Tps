﻿using System;
using System.Collections.Generic;
using System.Data;
using TP1_BiMA_lUCAS_421552.Data.Helpers;
using TP1_BiMA_lUCAS_421552.Data.Interfaces;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Data.Implementations
{
    public class DetalleRepository : IDetalleRepository
    {
        private readonly DataHelper _dataHelper;

        public DetalleRepository()
        {
            _dataHelper = DataHelper.GetInstance();
        }

        public List<DetalleFactura> GetByFactura(int nroFactura)
        {
            var detalles = new List<DetalleFactura>();
            var parametros = new List<SpParameter>
            {
                new SpParameter("@nroFactura", nroFactura)
            };

            DataTable dt = _dataHelper.ExecuteSPQuery("sp_obtener_detalles_por_factura", parametros);

            foreach (DataRow row in dt.Rows)
            {
                detalles.Add(new DetalleFactura
                {
                    Id = Convert.ToInt32(row["id"]),
                    NroFactura = Convert.ToInt32(row["nroFactura"]),
                    IdArticulo = Convert.ToInt32(row["idArticulo"]),
                    Cantidad = Convert.ToInt32(row["cantidad"]),
                    ArticuloNombre = row.Table.Columns.Contains("Articulo") ? row["Articulo"].ToString() : null,
                    PrecioUnitario = row.Table.Columns.Contains("precioUnitario") ? Convert.ToDecimal(row["precioUnitario"]) : 0
                });
            }

            return detalles;
        }

        public DetalleFactura? GetById(int id)
        {
            throw new NotImplementedException("Usar GetByFactura para obtener los detalles.");
        }

        public bool Save(DetalleFactura detalle)
        {
            var parametros = new List<SpParameter>
            {
                new SpParameter("@nroFactura", detalle.NroFactura),
                new SpParameter("@idArticulo", detalle.IdArticulo),
                new SpParameter("@cantidad", detalle.Cantidad)
            };

            int filas = _dataHelper.ExecuteSPDML("sp_insertar_detalle", parametros);
            return filas > 0;
        }

        public bool Delete(int id)
        {
            var parametros = new List<SpParameter>
            {
                new SpParameter("@idDetalle", id)
            };

            int filas = _dataHelper.ExecuteSPDML("sp_eliminar_detalle", parametros);
            return filas > 0;
        }
    }
}
