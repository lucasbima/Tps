﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace TP1_BiMA_lUCAS_421552.Data.Helpers
{
    public class DataHelper
    {
        private static DataHelper? _instance;
        private readonly SqlConnection _connection;

        private DataHelper()
        {
            // Ajustá el connection string a tu SQL Server
            _connection = new SqlConnection(
                @"Data Source=localhost\SQLEXPRESS;Initial Catalog=TP01;Integrated Security=True;Encrypt=False");
        }

        public static DataHelper GetInstance()
        {
            if (_instance == null)
                _instance = new DataHelper();
            return _instance;
        }

        private void Open()
        {
            if (_connection.State == ConnectionState.Closed)
                _connection.Open();
        }

        private void Close()
        {
            if (_connection.State == ConnectionState.Open)
                _connection.Close();
        }

        // Ejecuta SP de consulta (devuelve DataTable)
        public DataTable ExecuteSPQuery(string spName, List<SpParameter>? parametros = null)
        {
            DataTable tabla = new DataTable();

            try
            {
                Open();
                using (SqlCommand cmd = new SqlCommand(spName, _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parametros != null)
                    {
                        foreach (var p in parametros)
                        {
                            cmd.Parameters.AddWithValue(p.Name, p.Value ?? DBNull.Value);
                        }
                    }

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(tabla);
                    }
                }
            }
            finally
            {
                Close();
            }

            return tabla;
        }

        // Ejecuta SP de modificación (INSERT/UPDATE/DELETE)
        public int ExecuteSPDML(string spName, List<SpParameter>? parametros = null)
        {
            int filasAfectadas = 0;

            try
            {
                Open();
                using (SqlCommand cmd = new SqlCommand(spName, _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parametros != null)
                    {
                        foreach (var p in parametros)
                        {
                            cmd.Parameters.AddWithValue(p.Name, p.Value ?? DBNull.Value);
                        }
                    }

                    filasAfectadas = cmd.ExecuteNonQuery();
                }
            }
            finally
            {
                Close();
            }

            return filasAfectadas;
        }

        // Ejecuta SP con parámetro OUTPUT
        public int ExecuteSPWithOutput(string spName, string outputParam, List<SpParameter>? parametros = null)
        {
            int result = 0;

            try
            {
                Open();
                using (SqlCommand cmd = new SqlCommand(spName, _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parametros != null)
                    {
                        foreach (var p in parametros)
                        {
                            cmd.Parameters.AddWithValue(p.Name, p.Value ?? DBNull.Value);
                        }
                    }

                    // Parámetro OUTPUT
                    SqlParameter output = new SqlParameter(outputParam, SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    cmd.Parameters.Add(output);

                    cmd.ExecuteNonQuery();

                    result = Convert.ToInt32(output.Value);
                }
            }
            finally
            {
                Close();
            }

            return result;
        }
    }
}
