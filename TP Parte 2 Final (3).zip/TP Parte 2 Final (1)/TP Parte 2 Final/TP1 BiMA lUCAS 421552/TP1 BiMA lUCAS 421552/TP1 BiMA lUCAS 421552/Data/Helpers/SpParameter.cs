﻿namespace TP1_BiMA_lUCAS_421552.Data.Helpers
{
    public class SpParameter
    {
        public string Name { get; set; }
        public object Value { get; set; }

        public SpParameter() { }

        public SpParameter(string name, object value)
        {
            Name = name;
            Value = value;
        }
    }
}
