﻿using System;
using TP1_BiMA_lUCAS_421552.Domain;
using TP1_BiMA_lUCAS_421552.Services;

class Program
{
    static void Main(string[] args)
    {
        var facturaService = new FacturaService();
        var detalleService = new DetalleFacturaService();

        Console.WriteLine("=== Gestión de Facturas TP1 ===");

        while (true)
        {
            Console.WriteLine("\nOpciones:");
            Console.WriteLine("1 - Crear factura");
            Console.WriteLine("2 - Listar facturas");
            Console.WriteLine("3 - Eliminar factura");
            Console.WriteLine("4 - Ver detalles");
            Console.WriteLine("5 - Agregar detalle");
            Console.WriteLine("6 - Eliminar detalle");
            Console.WriteLine("0 - Salir");

            string? opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    CrearFactura(facturaService);
                    break;
                case "2":
                    ListarFacturas(facturaService);
                    break;
                case "3":
                    EliminarFactura(facturaService);
                    break;
                case "4":
                    VerDetalles(detalleService);
                    break;
                case "5":
                    AgregarDetalle(detalleService);
                    break;
                case "6":
                    EliminarDetalle(detalleService);
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Opción inválida");
                    break;
            }
        }
    }

    static void CrearFactura(FacturaService service)
    {
        Console.Write("Cliente: ");
        string cliente = Console.ReadLine() ?? "";
        Console.Write("IdFormaPago: ");
        int idFormaPago = int.Parse(Console.ReadLine() ?? "1");

        var factura = new Factura { Cliente = cliente, Fecha = DateTime.Now, IdFormaPago = idFormaPago };
        bool exito = service.GuardarFactura(factura);
        Console.WriteLine(exito ? $"Factura creada. Nro: {factura.NroFactura}" : "Error al crear factura");
    }

    static void ListarFacturas(FacturaService service)
    {
        var facturas = service.ObtenerFacturas();
        foreach (var f in facturas)
            Console.WriteLine($"Nro:{f.NroFactura} Cliente:{f.Cliente} Fecha:{f.Fecha.ToShortDateString()}");
    }

    static void EliminarFactura(FacturaService service)
    {
        Console.Write("NroFactura a eliminar: ");
        int nro = int.Parse(Console.ReadLine() ?? "0");
        bool exito = service.EliminarFactura(nro);
        Console.WriteLine(exito ? "Factura eliminada" : "Factura no encontrada");
    }

    static void VerDetalles(DetalleFacturaService service)
    {
        Console.Write("NroFactura: ");
        int nro = int.Parse(Console.ReadLine() ?? "0");
        var detalles = service.ObtenerDetallesPorFactura(nro);
        foreach (var d in detalles)
            Console.WriteLine($"Id:{d.Id} Articulo:{d.ArticuloNombre} Cantidad:{d.Cantidad} Precio:{d.PrecioUnitario}");
    }

    static void AgregarDetalle(DetalleFacturaService service)
    {
        Console.Write("NroFactura: ");
        int nroFactura = int.Parse(Console.ReadLine() ?? "0");
        Console.Write("IdArticulo: ");
        int idArticulo = int.Parse(Console.ReadLine() ?? "0");
        Console.Write("Cantidad: ");
        int cantidad = int.Parse(Console.ReadLine() ?? "1");

        var detalle = new DetalleFactura { NroFactura = nroFactura, IdArticulo = idArticulo, Cantidad = cantidad };
        bool exito = service.GuardarDetalle(detalle);
        Console.WriteLine(exito ? "Detalle agregado" : "Error al agregar detalle");
    }

    static void EliminarDetalle(DetalleFacturaService service)
    {
        Console.Write("Id detalle a eliminar: ");
        int id = int.Parse(Console.ReadLine() ?? "0");
        bool exito = service.EliminarDetalle(id);
        Console.WriteLine(exito ? "Detalle eliminado" : "Detalle no encontrado");
    }
}
