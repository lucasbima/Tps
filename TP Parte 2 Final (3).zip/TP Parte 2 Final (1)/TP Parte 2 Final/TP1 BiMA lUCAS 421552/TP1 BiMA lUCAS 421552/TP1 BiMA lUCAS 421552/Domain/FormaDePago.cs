﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1_BiMA_lUCAS_421552.Domain
{
    public class FormaDePago
    {
        public int Id { get; set; }

        public string Nombre { get; set; }


    }
}
