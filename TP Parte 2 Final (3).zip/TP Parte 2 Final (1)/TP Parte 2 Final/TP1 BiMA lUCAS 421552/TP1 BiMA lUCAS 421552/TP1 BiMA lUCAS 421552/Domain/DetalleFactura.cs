﻿namespace TP1_BiMA_lUCAS_421552.Domain
{
    public class DetalleFactura
    {
        public int Id { get; set; }
        public int NroFactura { get; set; }
        public int IdArticulo { get; set; }
        public int Cantidad { get; set; }

        // Opcional, solo si tu SP hace JOIN con Articulo
        public string? ArticuloNombre { get; set; }
        public decimal PrecioUnitario { get; set; }
    }
}
