﻿namespace TP1_BiMA_lUCAS_421552.Domain
{
    public class Factura
    {
        public int NroFactura { get; set; }
        public DateTime Fecha { get; set; }
        public int IdFormaPago { get; set; }
        public string Cliente { get; set; } = "";
        // FormaPagoNombre solo si tu SP lo devuelve
        public string? FormaPagoNombre { get; set; }
    }
}
