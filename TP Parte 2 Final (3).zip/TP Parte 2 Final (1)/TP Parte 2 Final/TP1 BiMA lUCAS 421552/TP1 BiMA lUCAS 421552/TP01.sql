CREATE DATABASE TP01;
GO

USE TP01;
GO

-- Tabla Articulo
CREATE TABLE Articulo (
    id INT PRIMARY KEY IDENTITY,
    nombre NVARCHAR(100) NOT NULL,
    precioUnitario DECIMAL(10,2) NOT NULL
);
GO

-- Tabla FormaPago
CREATE TABLE FormaPago (
    id INT PRIMARY KEY IDENTITY,
    nombre NVARCHAR(50) NOT NULL
);
GO

-- Tabla Factura
CREATE TABLE Factura (
    nroFactura INT PRIMARY KEY IDENTITY,
    fecha DATE NOT NULL,
    idFormaPago INT NOT NULL,
    cliente NVARCHAR(100) NOT NULL,
    FOREIGN KEY (idFormaPago) REFERENCES FormaPago(id)
);
GO

-- Tabla DetalleFactura
CREATE TABLE DetalleFactura (
    id INT PRIMARY KEY IDENTITY,
    nroFactura INT NOT NULL,
    idArticulo INT NOT NULL,
    cantidad INT NOT NULL,
    FOREIGN KEY (nroFactura) REFERENCES Factura(nroFactura),
    FOREIGN KEY (idArticulo) REFERENCES Articulo(id)
);
GO

/* ======================
   PROCEDIMIENTOS ALMACENADOS
   ====================== */

-- Insertar factura
CREATE PROCEDURE sp_insertar_factura
    @fecha DATE,
    @idFormaPago INT,
    @cliente NVARCHAR(100),
    @idFactura INT OUTPUT
AS
BEGIN
    INSERT INTO Factura(fecha, idFormaPago, cliente)
    VALUES (@fecha, @idFormaPago, @cliente);

    SET @idFactura = CAST(SCOPE_IDENTITY() AS INT);
END;
GO

-- Insertar detalle
CREATE PROCEDURE sp_insertar_detalle
    @nroFactura INT,
    @idArticulo INT,
    @cantidad INT
AS
BEGIN
    INSERT INTO DetalleFactura(nroFactura, idArticulo, cantidad)
    VALUES (@nroFactura, @idArticulo, @cantidad);
END;
GO

-- Obtener todas las facturas
CREATE PROCEDURE sp_obtener_facturas
AS
BEGIN
    SELECT f.nroFactura, f.fecha, f.idFormaPago, f.cliente, fp.nombre AS FormaPago
    FROM Factura f
    INNER JOIN FormaPago fp ON f.idFormaPago = fp.id;
END;
GO

-- Obtener factura por ID
CREATE PROCEDURE sp_obtener_factura_por_id
    @idFactura INT
AS
BEGIN
    SELECT f.nroFactura, f.fecha, f.idFormaPago, f.cliente, fp.nombre AS FormaPago
    FROM Factura f
    INNER JOIN FormaPago fp ON f.idFormaPago = fp.id
    WHERE f.nroFactura = @idFactura;
END;
GO

-- Eliminar factura (con detalles asociados)
CREATE PROCEDURE sp_eliminar_factura
    @idFactura INT
AS
BEGIN
    DELETE FROM DetalleFactura WHERE nroFactura = @idFactura;
    DELETE FROM Factura WHERE nroFactura = @idFactura;
END;
GO

-- Obtener detalles por factura
CREATE PROCEDURE sp_obtener_detalles_por_factura
    @nroFactura INT
AS
BEGIN
    SELECT d.id, d.nroFactura, d.idArticulo, a.nombre AS Articulo, d.cantidad, a.precioUnitario
    FROM DetalleFactura d
    INNER JOIN Articulo a ON d.idArticulo = a.id
    WHERE d.nroFactura = @nroFactura;
END;
GO

-- Eliminar detalle
CREATE PROCEDURE sp_eliminar_detalle
    @idDetalle INT
AS
BEGIN
    DELETE FROM DetalleFactura WHERE id = @idDetalle;
END;
GO
