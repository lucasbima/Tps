using Microsoft.EntityFrameworkCore;
using TP3_Programacion.Data.Models;
using TP3_Programacion.Data.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<FacturaContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))); //agregar

builder.Services.AddScoped<IFacturaRepository, FacturaRepository>(); //da una definicion al contenedor de dependencia, para cuando cree un obj de la clase
                                                                     //si el obj es de interfaz repo, crea un�obj�new�de�repo

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
