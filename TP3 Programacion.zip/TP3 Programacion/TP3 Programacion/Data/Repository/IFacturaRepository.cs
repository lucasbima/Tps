﻿using TP3_Programacion.Data.Models;

namespace TP3_Programacion.Data.Repository
{
    public interface IFacturaRepository
    {
        void Create(Factura factura);

        void Update(Factura factura);

        List<Factura> GetAll();

        Factura? GetById(int id);

        void Delete(int id);
    }
}
