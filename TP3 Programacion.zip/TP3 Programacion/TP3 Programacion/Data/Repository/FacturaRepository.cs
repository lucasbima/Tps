﻿using TP3_Programacion.Data.Models;

namespace TP3_Programacion.Data.Repository
{
    public class FacturaRepository : IFacturaRepository
    {
        public FacturaContext _context; 

        public FacturaRepository(FacturaContext context)
        {
            _context = context;
        }
        public void Create(Factura factura)
        {
            _context.Facturas.Add(factura);

            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var facturaDeleted = GetById(id);

            if (facturaDeleted != null)
            {
                _context.Facturas.Remove(facturaDeleted);

                _context.SaveChanges();
            }
        }

        public List<Factura> GetAll()
        {
            return _context.Facturas.ToList();
        }

        public Factura? GetById(int id)
        {
            return _context.Facturas.Find(id);
        }

        public void Update(Factura factura)
        {
            _context.Facturas.Update(factura);

            _context.SaveChanges();
        }
    }
}
