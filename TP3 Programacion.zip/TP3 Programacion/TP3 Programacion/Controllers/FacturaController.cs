﻿using Microsoft.AspNetCore.Mvc;
using TP3_Programacion.Data.Models;
using TP3_Programacion.Data.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TP3_Programacion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : ControllerBase
    {
        private IFacturaRepository _repository; //creado por el contenedor de dependencia (program)

        public FacturaController(IFacturaRepository repository)
        {
            _repository = repository;
        }

        // GET: api/<FacturaController>
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(_repository.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(500, "Ha ocurrido un error interno!");
            }
        }


        // POST api/<FacturaController>
        [HttpPost]
        public IActionResult Post([FromBody] Factura value) //a partir del json que viene en el body del http request por metodo post, recuperar y armar un obj factura
        {
            try
            {
                if (IsValid(value)) //validaciones de datos 
                {
                    _repository.Create(value);
                    return Ok("Factura insertada");
                }
                else
                {
                    BadRequest("Los datos no son correctos o incompletos");

                }
                return Ok();

            }
            catch (Exception)
            {
                return StatusCode(500, "Ha ocurrido un error interno!");
            }
        }


        // DELETE api/Factura/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id) // <-- lo tomamos de la ruta, no del body
        {
            try
            {
                // Verificar si existe antes de borrar (opcional)
                var factura = _repository.GetById(id);
                if (factura == null)
                {
                    return NotFound($"No existe la factura con ID {id}");
                }

                _repository.Delete(id); // acá llamás al repo para que borre
                return Ok($"Factura con ID {id} borrada con éxito!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Ha ocurrido un error interno: {ex.Message}");
            }
        }

        //get by id

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {

            try
            {
                return Ok(_repository.GetById(id));
            }
            catch (Exception)
            {
                return StatusCode(500, "Ha ocurrido un error interno!");
            }
        }


        private bool IsValid(Factura value)
        {
            return !string.IsNullOrEmpty(value.Cliente);
        }

        // PUT api/Factura/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Factura value)
        {
            try
            {
                var facturaExistente = _repository.GetById(id); // esto devuelve entidad ya trackeada

                if (facturaExistente == null)
                    return NotFound($"No existe la factura con ID {id}");

                // actualizar campos sobre la misma instancia ya cargada
                facturaExistente.Fecha = value.Fecha;
                facturaExistente.IdFormaPago = value.IdFormaPago;
                facturaExistente.Cliente = value.Cliente;

                _repository.Update(facturaExistente); // pasás la misma instancia
                return Ok($"Factura con ID {id} actualizada con éxito!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Ha ocurrido un error interno: {ex.Message}");
            }
        }
    }
}