﻿using System.Collections.Generic;
using TP1_BiMA_lUCAS_421552.Data.Implementations;
using TP1_BiMA_lUCAS_421552.Data.Interfaces;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Services
{
    public class FacturaService
    {
        private readonly IFacturaRepository _facturaRepository;

        public FacturaService()
        {
            _facturaRepository = new FacturaRepository();
        }

        public List<Factura> ObtenerFacturas()
        {
            return _facturaRepository.GetAll();
        }

        public Factura? ObtenerFacturaPorId(int id)
        {
            return _facturaRepository.GetById(id);
        }

        public bool GuardarFactura(Factura factura)
        {
            return _facturaRepository.Save(factura);
        }

        public bool EliminarFactura(int id)
        {
            return _facturaRepository.Delete(id);
        }
    }
}
