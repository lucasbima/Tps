﻿using System.Collections.Generic;
using TP1_BiMA_lUCAS_421552.Domain;

namespace TP1_BiMA_lUCAS_421552.Data.Interfaces
{
    public interface IFacturaRepository
    {
        List<Factura> GetAll();
        Factura? GetById(int id);
        bool Save(Factura factura);
        bool Delete(int id);
    }
}
